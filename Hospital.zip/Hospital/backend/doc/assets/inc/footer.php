<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2024 - <?php echo date('Y'); ?> &copy; Hospital Management Information System. Developed By Clinton Moindi  </a>
            </div>

        </div>
    </div>
</footer>