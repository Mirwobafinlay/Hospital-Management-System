<footer class="footer footer-alt">
    2020 - <?php echo date('Y'); ?> &copy; Hospital Management System. Developed By Clinton Moindi </a>
</footer>